Made using Horsie's Viewmodel Editor
https://github.com/a-horsey/horsies-viewmodel-editor
https://gamebanana.com/tools/10146